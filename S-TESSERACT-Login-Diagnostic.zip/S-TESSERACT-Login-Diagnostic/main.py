import os
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

app = FastAPI(title='S-TESSERACT Login Diagnostic')

class LoginPayload(BaseModel):
    username: str
    password: str

HTML = r'''<!doctype html><html lang="ar" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>S-TESSERACT Login Diagnostic</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;font-family:system-ui,Arial;background:#0b1020;color:#f4f7ff}.card{width:min(100%,420px);padding:28px;border-radius:18px;background:#151d33;border:1px solid #2c3856;box-shadow:0 18px 60px #0005}h1{margin:0 0 8px;font-size:25px}p{color:#bdc8df;line-height:1.7}label{display:block;margin:16px 0 7px}input{width:100%;padding:12px;border-radius:10px;border:1px solid #405072;background:#0d1427;color:white;font:inherit}button{width:100%;margin-top:20px;padding:13px;border:0;border-radius:10px;background:#6d8cff;color:#081027;font:inherit;font-weight:700;cursor:pointer}button:disabled{opacity:.6;cursor:wait}#status{margin-top:16px;padding:12px;border-radius:10px;background:#0d1427;white-space:pre-wrap;overflow-wrap:anywhere;min-height:46px}.hint{font-size:13px}
</style></head><body><main class="card"><h1>S-TESSERACT</h1><p>صفحة اختبار مستقلة لتشخيص الاتصال بين المتصفح والسيرفر.</p><form id="loginForm"><label for="username">اسم اختبار</label><input id="username" autocomplete="username" placeholder="اكتب أي اسم للاختبار" required><label for="password">كلمة مرور اختبار</label><input id="password" type="password" autocomplete="current-password" placeholder="اكتب أي قيمة" required><button id="loginBtn" type="submit">اختبر تسجيل الدخول</button></form><div id="status" role="status" aria-live="polite">الحالة: الصفحة ظهرت بنجاح.</div><p class="hint">تنبيه: هذه صفحة تشخيص فقط. لا يوجد حساب حقيقي، ولا تحفظ أو تتحقق من كلمات المرور.</p></main><script>
(() => { const form=document.getElementById('loginForm'), button=document.getElementById('loginBtn'), status=document.getElementById('status'); form.addEventListener('submit',async(event)=>{ event.preventDefault(); status.textContent='1/3: الزر استجاب. جاري الاتصال بالسيرفر...'; button.disabled=true; try { const response=await fetch('/api/login-test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:document.getElementById('username').value,password:document.getElementById('password').value})}); const data=await response.json(); if(!response.ok) throw new Error('HTTP '+response.status); status.textContent='2/3: المتصفح وصل للسيرفر.\n3/3: '+data.message+'\nHTTP Status: '+response.status; } catch(error) { status.textContent='الزر استجاب، لكن طلب السيرفر فشل.\nالتفاصيل: '+(error&&error.message?error.message:String(error)); } finally { button.disabled=false; } }); })();
</script></body></html>'''

@app.get('/', response_class=HTMLResponse)
def home():
    return HTML

@app.get('/health')
def health():
    return {'status': 'ok', 'message': 'Server is reachable'}

@app.post('/api/login-test')
def login_test(payload: LoginPayload):
    # Diagnostic only: values are not stored or logged.
    if not payload.username.strip() or not payload.password:
        return JSONResponse(status_code=400, content={'message': 'أدخل القيم المطلوبة'})
    return {'status': 'ok', 'message': 'نجح اختبار الاتصال بين الصفحة والسيرفر.'}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('main:app', host='0.0.0.0', port=int(os.environ.get('PORT', '8000')))
