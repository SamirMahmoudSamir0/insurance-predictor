# S-TESSERACT Login Diagnostic

A minimal diagnostic app, not real authentication.

## Run locally
```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
python main.py
```
Open http://127.0.0.1:8000

## Deploy
Build/install: `pip install -r requirements.txt`
Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`

Check `/health` for a JSON health response.

## Interpret results
- Page won't load: deployment, routing, build, or server issue.
- Page loads but button does nothing: browser JavaScript issue; inspect DevTools Console.
- Button reacts but request fails: endpoint/network/server routing issue.
- Success message: basic browser-to-server connection works; this does not prove the original app's authentication/database works.

Do not enter real credentials. Submitted values are not stored.
